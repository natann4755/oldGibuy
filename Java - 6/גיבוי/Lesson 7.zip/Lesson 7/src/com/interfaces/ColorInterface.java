package com.interfaces;

public interface ColorInterface {
    Color getColor();
    void setColor(Color c);
    boolean canChangeColor();
}
