package com.interfaces;

public class Animal implements ColorInterface {
    Color color;


    public Color getColor() {
        return null;
    }


    public void setColor(Color c) {

    }


    public boolean canChangeColor() {
        return false;
    }
}
