package com.ny.ravtech.colors;

import com.interfaces.ColorInterface;

public class ColorHandler {

    public static boolean isColorValid(ColorInterface obj){
        return false;
    }

}
