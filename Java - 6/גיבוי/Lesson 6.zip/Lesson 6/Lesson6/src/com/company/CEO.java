package com.company;

public class CEO extends Manager {

    public CEO(String name, String last, int salary, Manager[] managers) {
        super(name, last, salary, managers);
    }
}
