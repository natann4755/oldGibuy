package com.colors;

import java.io.PrintStream;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class MyClass {


    public static void main(String[] args) {
//        Color w = Color.WHITE;
        System.out.println();
        Scanner scan = new Scanner(System.in);

    }
}
