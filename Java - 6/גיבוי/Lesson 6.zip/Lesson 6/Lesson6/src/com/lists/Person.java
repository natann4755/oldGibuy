package com.lists;

public class Person {
    String name;
    String last;

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", last='" + last + '\'' +
                '}';
    }
}
