package com.equals;

public class Animal {
    String animalName;
}
