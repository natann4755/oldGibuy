package com.equals;

public class Student extends Person {
}
