package javam.button;

public interface OnClickListener {
    void onClick(Button b);
}
