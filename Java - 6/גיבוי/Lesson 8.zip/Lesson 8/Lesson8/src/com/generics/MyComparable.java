package com.generics;


public interface MyComparable <T>{
    int compareTo(T another);
}
