package com.generics;

import java.util.ArrayList;

public class MainClass {
    public static void main(String[] args) {
        ArrayList<Person> list = new ArrayList();
        ArrayList<String> strings = new ArrayList();
        Generic <Person> generic = new Generic();
    }
}
