package com.anonymous;

public class Person {
    String name, last;
}
