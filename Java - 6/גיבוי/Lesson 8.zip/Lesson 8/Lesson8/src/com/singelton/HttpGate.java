package com.singelton;

public class HttpGate {


}
