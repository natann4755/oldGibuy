package com.company;

public class Animal {
}
