package com.company;

public class Person implements Comparable {

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
