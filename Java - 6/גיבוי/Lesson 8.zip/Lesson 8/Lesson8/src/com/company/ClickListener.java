package com.company;

public interface ClickListener {
    void onClick(Object src);
}
