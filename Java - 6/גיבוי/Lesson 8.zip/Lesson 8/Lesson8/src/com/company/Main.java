package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Person> people = new ArrayList<>();
        ArrayList<Animal> animals = new ArrayList<>();

        Container container = new Container();
        while (true) {
            System.out.println("Click x: ");
            int x = Integer.parseInt(scan.nextLine());
            container.onUserClick(x, 0);
        }

    }

    public static void sort(Comparable obj){

    }
}
