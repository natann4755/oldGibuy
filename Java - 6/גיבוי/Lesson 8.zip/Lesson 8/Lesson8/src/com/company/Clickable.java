package com.company;

public interface Clickable {
    void click();
    void setOnClickListener(ClickListener listener);
}
