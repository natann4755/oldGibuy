package com.company.Other;

import com.company.Animal;
import com.company.Dog;

public class Main2 {
    public static void main(String[] args) {
         Dog S=new Dog();
         S.setAge(7);
        System.out.println(S);
         Cat K=new Cat();
         K.setAge(7);
        System.out.println(K);

    }
}