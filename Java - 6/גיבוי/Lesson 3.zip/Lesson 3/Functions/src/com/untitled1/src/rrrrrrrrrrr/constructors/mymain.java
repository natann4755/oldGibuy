package rrrrrrrrrrr.constructors;

public class mymain {
    public static void main(String[] args) {
        person m=new person("moti","katz",22/03/1989);

        person c= new person(m);
        System.out.println(c);
    }
}
