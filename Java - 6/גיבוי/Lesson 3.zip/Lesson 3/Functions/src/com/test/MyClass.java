package com.test;

public class MyClass {
}
